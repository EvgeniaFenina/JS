const car = (name ,model, owner, year, phone, img) => 
	({name, model, owner, year, phone, img})
const log =(text, type, date = new Date()) => ({text, type, date})

const cars = [
	car('Porshe', 'Panamera', 
		'Evgenia', '2019', 
		'+7 645 456 77 77', 'img/porshe.jpg'),
	car('Nissan', 'Juke', 
		'Olga', '2018', 
		'+7 645 456 88 88', 'img/nissanJuke.jpg'),
	car('Audi', 'A3', 
		'Maria', '2017', 
		'+7 645 456 99 99', 'img/audiA3.jpg'),
	car('Mini cooper', 'Cabrio', 
		'Victoria', '2016', 
		'+7 645 456 55 55', 'img/miniCabrio.jpg'),
	car('Mazda', 'CX-5',
		'Aleksandr', '2016',
		'+7 645 456 44 44', 'img/Mazda-cx-5.jpg')
]

new Vue({
	el: '#app',
	data: {
		cars: cars,
		car: cars[0],
		logs: [],
		selectedCarIndex: 0,
		phoneVisibility:  false,
		modalVisibility: false
	},
	methods: {
		selectCar(index){
		
			this.car = cars[index]
			this.selectedCarIndex = index
		},
		cancelOrder(){
			this.modalVisibility = false
			this.logs.push(
				log(`Cancelled order: ${this.car.name} - ${this.car.model}`, 'cnsl')
				)

		},
		buyCar(){
			this.modalVisibility = false
			this.logs.push(
				log(`Success order: ${this.car.name} - ${this.car.model}`, 'ok')
				)
		}
	},
	computed: {
		phoneButtonText(){
			return this.phoneVisibility ? 'Close phone' : 'Show phone'
		}
	},
	filters: {
		date(value) {
			return value.toLocaleString();
		}
	}
}) 